package com.cg.lams.dao;

import java.util.List;

import com.cg.lams.entity.EndUsers;
import com.cg.lams.entity.LoanProgramsOffered;
import com.cg.lams.exception.LAMSException;

public interface CommonDao {

	public EndUsers login(EndUsers user)throws LAMSException;

	public List<LoanProgramsOffered> viewLoanProgramOffered();

	public LoanProgramsOffered getAllLoanPrograms(String programName);
	
}
