package com.cg.lams.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.lams.entity.CustomerDetails;
import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;

@Repository
public class CustomerDaoImpl implements CustomerDao {

	@PersistenceContext
	EntityManager em;

	@Override
	public LoanProgramsOffered getLoanProgram(String programName) {
		// TODO Auto-generated method stub
		return em.find(LoanProgramsOffered.class, programName);
	}

	@Override
	public void addLoanDetails(LoanApplication loanApplication) {
		// TODO Auto-generated method stub
		em.persist(loanApplication);
	}

	@Override
	public void addCustDetails(CustomerDetails customerDetails) {
		// TODO Auto-generated method stub
		em.persist(customerDetails);
	}
}
