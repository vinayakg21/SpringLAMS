package com.cg.lams.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.lams.entity.EndUsers;
import com.cg.lams.entity.LoanProgramsOffered;
import com.cg.lams.exception.LAMSException;
import com.cg.lams.service.AdminService;
import com.cg.lams.service.CommonService;

@Controller
public class LAMSController {
	
	@Autowired
	CommonService cser;
	
	@Autowired
	AdminService aser;
	

	public LAMSController() {
		// TODO Auto-generated constructor stub
	}
	
	@RequestMapping("adminPage")
	public String goAdminLogin(Model model){
		
		model.addAttribute("user", new EndUsers());
		return "AdminLogin";
		
	}
	
	@RequestMapping("ladPage")
	public String goLADLogin(Model model){
		
		model.addAttribute("user", new EndUsers());
		return "LADLogin";
		
	}
	
	@RequestMapping("customerPage")
	public String goCustomerHome(Model model){
		
		return "CustomerHome";
		
	}
	
	@RequestMapping("adminLoginAction")
	public String adminLogin(@ModelAttribute("user") @Valid EndUsers user, BindingResult res,Model model) throws LAMSException{
		user.setRole("Admin");
		if(res.hasErrors()){
			model.addAttribute("user",user);
			return "AdminLogin";
		}
		else
		{
			EndUsers userResult = null;			
			try {
				userResult = cser.login(user);
			} catch (LAMSException e) {
				// TODO Auto-generated catch block
				throw new LAMSException("Invalid User");
			}
			return "AdminHome";
		}
	}
	
	@RequestMapping("ladLoginAction")
	public String ladlogin(@ModelAttribute("user") @Valid EndUsers user, BindingResult res,Model model) throws LAMSException{
		user.setRole("LAD");
		if(res.hasErrors()){
			model.addAttribute("user",user);
			return "LADLogin";
		}
		else
		{
			EndUsers userResult = null;			
			try {
				userResult = cser.login(user);
			} catch (LAMSException e) {
				// TODO Auto-generated catch block
				throw new LAMSException("Invalid User");
			}
			return "LADHome";
		}
	}	
	
	@ExceptionHandler(value=LAMSException.class)
	public String handleException(Model model,Exception e) {
		
		System.out.println(e.getMessage());
		model.addAttribute("message", e.getMessage());
		return "Exception";
	}

	@ExceptionHandler(value=NullPointerException.class)
	public String handleNullPointerException(Model model,Exception e) {
		
		System.out.println(e.getMessage());
		model.addAttribute("message", e.getMessage());
		return "Exception";
	}
	
	@RequestMapping("addLoanPage")
	public String goAddLoan(Model model){
		
		model.addAttribute("loanProgram", new LoanProgramsOffered());
		return "AddLoanProgram";
		
	}
	
	@RequestMapping("addLoanProgramAction")
	public String register(@ModelAttribute("loanProgram") @Valid LoanProgramsOffered loanProgram, BindingResult res,Model model){
		
		if(res.hasErrors()){
			model.addAttribute("loanProgram",loanProgram);
			return "AddLoanProgram";
		}
		else
		{
			aser.addLoanProgram(loanProgram);
			System.out.println("Swastika");
			System.out.println(loanProgram);
			//model.addAttribute("msg","Loan Program Added Successfully with name"+loanProgram.getProgramName());
			return "ADDLoanProgramSuccess";
		}
	}
	
}
