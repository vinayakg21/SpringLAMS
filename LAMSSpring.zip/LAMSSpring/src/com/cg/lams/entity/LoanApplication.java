package com.cg.lams.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="lapsloanapplication")
public class LoanApplication {	

	@Id
	@SequenceGenerator(name="Id_seq", sequenceName="seq_application_id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="Id_seq")	
	@Column(name="APPLICATION_ID")
	int applicationId;
	
	@Column(name="APPLICATION_DATE")
	Date applicationDate;
	
	@Column(name="LOAN_PROGRAM")
	String loanProgram;
	
	@Column(name="AMOUNTOFLOAN")
	@NotNull(message="Please Enter the Amount of the Loan")
	int amountOfLoan;
	
	@Column(name="ADDRESSOFPROPERTY")
	@NotEmpty(message="Please Enter the Address")
	String addressOfProperty;
	
	@Column(name="ANNUALFAMILYINCOME")
	@NotNull(message="Please Enter the Annual Family Income")
	int annualFamilyIncome;
	
	@Column(name="DOCUMENTPROOFSAVAILABLE")
	@NotEmpty(message="Please Enter the Document Proofs")	
	String documentProofsAvailable;
	
	@Column(name="GUARANTEECOVER")
	@NotEmpty(message="Please Enter the Guarantee Cover")
	String guaranteeCover;
	
	@Column(name="MARKETVALUEOFGUARANTEECOVER")
	@NotNull(message="Please Enter the Market value Of the Guarantee Cover")
	int marketValueofGuaranteeCover;
	
	@Column(name="STATUS")
	String status;
	
	@Column(name="DATEOFINTERVIEW")
	Date dateOfInterview;

	public LoanApplication() {
		// TODO Auto-generated constructor stub
	}

	public LoanApplication(int applicationId, Date applicationDate,
			String loanProgram, int amountOfLoan, String addressOfProperty,
			int annualFamilyIncome, String documentProofsAvailable,
			String guaranteeCover, int marketValueofGuaranteeCover,
			String status, Date dateOfInterview) {
		super();
		this.applicationId = applicationId;
		this.applicationDate = applicationDate;
		this.loanProgram = loanProgram;
		this.amountOfLoan = amountOfLoan;
		this.addressOfProperty = addressOfProperty;
		this.annualFamilyIncome = annualFamilyIncome;
		this.documentProofsAvailable = documentProofsAvailable;
		this.guaranteeCover = guaranteeCover;
		this.marketValueofGuaranteeCover = marketValueofGuaranteeCover;
		this.status = status;
		this.dateOfInterview = dateOfInterview;
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public Date getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	public String getLoanProgram() {
		return loanProgram;
	}

	public void setLoanProgram(String loanProgram) {
		this.loanProgram = loanProgram;
	}

	public int getAmountOfLoan() {
		return amountOfLoan;
	}

	public void setAmountOfLoan(int amountOfLoan) {
		this.amountOfLoan = amountOfLoan;
	}

	public String getAddressOfProperty() {
		return addressOfProperty;
	}

	public void setAddressOfProperty(String addressOfProperty) {
		this.addressOfProperty = addressOfProperty;
	}

	public int getAnnualFamilyIncome() {
		return annualFamilyIncome;
	}

	public void setAnnualFamilyIncome(int annualFamilyIncome) {
		this.annualFamilyIncome = annualFamilyIncome;
	}

	public String getDocumentProofsAvailable() {
		return documentProofsAvailable;
	}

	public void setDocumentProofsAvailable(String documentProofsAvailable) {
		this.documentProofsAvailable = documentProofsAvailable;
	}

	public String getGuaranteeCover() {
		return guaranteeCover;
	}

	public void setGuaranteeCover(String guaranteeCover) {
		this.guaranteeCover = guaranteeCover;
	}

	public int getMarketValueofGuaranteeCover() {
		return marketValueofGuaranteeCover;
	}

	public void setMarketValueofGuaranteeCover(int marketValueofGuaranteeCover) {
		this.marketValueofGuaranteeCover = marketValueofGuaranteeCover;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDateOfInterview() {
		return dateOfInterview;
	}

	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}

	@Override
	public String toString() {
		return "LoanApplication [applicationId=" + applicationId
				+ ", applicationDate=" + applicationDate + ", loanProgram="
				+ loanProgram + ", amountOfLoan=" + amountOfLoan
				+ ", addressOfProperty=" + addressOfProperty
				+ ", annualFamilyIncome=" + annualFamilyIncome
				+ ", documentProofsAvailable=" + documentProofsAvailable
				+ ", guaranteeCover=" + guaranteeCover
				+ ", marketValueofGuaranteeCover="
				+ marketValueofGuaranteeCover + ", status=" + status
				+ ", dateOfInterview=" + dateOfInterview + "]";
	}
	
	
	
}
